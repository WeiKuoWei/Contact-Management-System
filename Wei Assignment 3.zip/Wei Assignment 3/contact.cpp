// #include<string>
// #include<fstream>
// #include<ostream>
// #include<exception>
// #include<sstream>
// #include<cstdlib>
// #include<ctime>
// #include<iomanip>
// #include<algorithm>
// #include<cctype>
// #include<typeinfo>

#include <iostream>
#include "contact.h"

using namespace std;


// Contact::Contact(string fname, string lname, string email, string primaryPhone, string city, string country, bool isFav)
// :fname(fname), lname(lname), email(email), primaryPhone(primaryPhone), city(city), country(country), isFav(isFav)
// {}

